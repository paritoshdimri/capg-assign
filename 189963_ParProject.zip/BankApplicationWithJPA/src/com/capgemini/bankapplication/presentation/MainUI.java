package com.capgemini.bankapplication.presentation;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.bankapplication.beans.Customer;
import com.capgemini.bankapplication.beans.Transaction;
import com.capgemini.bankapplication.exception.BAException;
import com.capgemini.bankapplication.service.BankApplicationService;
import com.capgemini.bankapplication.service.BankApplicationServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String continueChoice;
		boolean continueValue = false;

		Scanner scanner = null;
		do {

			System.out.println("** welcome to Bank Application **");
			System.out.println("1.create account");
			System.out.println("2.deposit");
			System.out.println("3.withdraw");
			System.out.println("4.print customer by id");
			System.out.println("5.fund transfer");
			System.out.println("6.print transaction by id");
			System.out.println("7.show balance");
			System.out.println("8.Exit");

			BankApplicationService service = new BankApplicationServiceImpl();
			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter input:");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean nameFlag = false;

					String name = "";
					switch (choice) {

					case 1:{
						
						
						
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter name:");
							name = scanner.nextLine();
							try {
								service.validateName(name);
								nameFlag = true;
							} catch (InputMismatchException e) {
								nameFlag = false;
								System.err.println("name should be in string");
							} catch (BAException e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!nameFlag);

						String address="";
						boolean addressFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter address:");
							try {
								address = scanner.nextLine();
							    addressFlag = true;
							} catch (InputMismatchException e) {
								addressFlag = false;
								System.err.println("Address should be in string");
							/*} catch (BAException e) {
								addressFlag = false;
								System.err.println(e.getMessage());*/
							}
						} while (!addressFlag);

						
						String email="";
						boolean mailFlag=false;
						do {
							scanner = new Scanner(System.in);
						System.out.println("Enter email:");
						email = scanner.nextLine();
						try {
							service.isValid(email);
						    mailFlag = true;
						} catch (InputMismatchException e) {
							mailFlag = false;
							System.err.println("email should be in format");
						} catch (BAException e) {
							mailFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!mailFlag);
						long mobileNo=0;
						boolean mobFlag=false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter mobile no:");
							mobileNo = scanner.nextLong();
							try {
								service.validateMobile(mobileNo);
								mobFlag = true;
							} catch (InputMismatchException e) {
								mobFlag = false;
								System.err.println("mobileNo should be in digits");
							} catch (BAException e) {
								mobFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!mobFlag);
						double balance=0.0;
						boolean balFlag=false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter balance:");
							
							try {
								balance = scanner.nextInt();
								service.validateBalance(balance);
								balFlag = true;
							} catch (InputMismatchException e) {
								mailFlag = false;
								System.err.println("Balance should be in digits");
							} catch (BAException e) {
								balFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!balFlag);
						

						Customer customer = new Customer(name, address, email, mobileNo, balance);
						try {
							int genearatedId = service.createAccount(customer);
							System.out.println("customer information stored with the given id: " + genearatedId);
						} catch (BAException e) {
							System.err.println(e.getMessage());
						}
					}

						break;
						
					case 2:
					{

						boolean custFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter accountNo to deposit balance:");
							try {
								int accountNo = scanner.nextInt();
								service.validateAccountNo(accountNo);
								System.out.println("Enter amount to deposit");
								double amountToDeposit = scanner.nextDouble();
								double finalBalance=service.deposit(accountNo, amountToDeposit);
								System.out.println("Successfully deposited! Your updated balance is: "+finalBalance);
								break;
							} catch (BAException e) {
								custFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!custFlag);

						break;
					}
						
						
					case 3:
					{

						boolean custFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter accountNo to withdraw balance:");
							try {
								int accountNo = scanner.nextInt();
								service.validateAccountNo(accountNo);
								System.out.println("Enter amount to withdraw");
								double amountToWithdraw = scanner.nextDouble();
								double finalBalance=service.withdraw(accountNo, amountToWithdraw);
								System.out.println("Successfully withdrawed! Your updated balance is: "+finalBalance);
								break;
							} catch (BAException e) {
								custFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!custFlag);

						break;
					}

				
					case 4:boolean idFlag = false;
					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter accountNo to check transaction:");
						try {
							int accountNo = scanner.nextInt();
							//service.validateCustId(custId);
							System.out.println(service.printCustomers(accountNo));
							idFlag=true;
							break;
						} catch (BAException e) {
							idFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!idFlag);


						break;
						
					case 5: {

						boolean custFlag = false;
						do {
							scanner = new Scanner(System.in);
							
							try {
								System.out.println("Enter your account number");
								int accountNo = scanner.nextInt();
								service.validateAccountNo(accountNo);
								System.out.println("Enter recipient account number");
								int destinationAccNo = scanner.nextInt();
								service.validateAccountNo(destinationAccNo);
								System.out.println("Enter amount to transfer");
								double amount = scanner.nextDouble();
								service.fundTransfer(accountNo, destinationAccNo,amount);
								System.out.println("Successfull transaction");
								break;
							} catch (BAException e) {
								custFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!custFlag);

						break;
					}
						
					case 6: boolean idFlag1 = false;
					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter accountNo to check transaction:");
						try {
							int accountNo = scanner.nextInt();
							System.out.println(service.printTransactions(accountNo));
							idFlag1=true;
							break;
						} catch (BAException e) {
							idFlag1 = false;
							System.err.println(e.getMessage());
						}
					} while (!idFlag1);


						break;
						
					case 7:{

						boolean custFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter accountNo to check balance:");
							try {
								int accountNo = scanner.nextInt();
								service.validateAccountNo(accountNo);

								System.out.println(service.showBalance(accountNo));
							break;
							} catch (BAException e) {
								custFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!custFlag);
						break;
					}

				
						
					case 8:
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;
					default:
						System.out.println("input should be from 1-9");
						choiceFlag = false;
						break;
					}

				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}
			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (continueValue);
		scanner.close();
	}


	}

