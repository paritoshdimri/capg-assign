package com.capgemini.bankapplication.service;

import java.util.List;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.bankapplication.beans.Customer;
import com.capgemini.bankapplication.beans.Transaction;
import com.capgemini.bankapplication.dao.BankApplicationDAO;
import com.capgemini.bankapplication.dao.BankApplicationDAOImpl;
import com.capgemini.bankapplication.exception.BAException;

public class BankApplicationServiceImpl implements BankApplicationService {
BankApplicationDAO dao = new BankApplicationDAOImpl();
EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
EntityManager em = factory.createEntityManager();
	@Override
	public int createAccount(Customer customer) throws BAException {
		// TODO Auto-generated method stub
		return dao.createAccount(customer);
	}

	@Override
	public double deposit(int accountNo, double amountToDeposit) throws BAException {
		// TODO Auto-generated method stub
		  return dao.deposit(accountNo, amountToDeposit);
		 
		
	}

	@Override
	public double withdraw(int accountNo, double amountToWithdraw) throws BAException {
		// TODO Auto-generated method stub
		return dao.withdraw(accountNo, amountToWithdraw);
		 
	}

	@Override
	public List<Customer> printCustomers(int accountNo) throws BAException {
		
			return dao.printCustomers(accountNo);
		
	}


	@Override
	public int fundTransfer(int accountNo, int destinationAccNo,double amount) throws BAException {
		return dao.fundTransfer(accountNo, destinationAccNo, amount);
	}

	@Override
	public List<Transaction> printTransactions(int accountNo) throws BAException {
		// TODO Auto-generated method stub
		return dao.printTransactions(accountNo);
		
	}

	@Override
	public void validateName(String name) throws BAException {
		// TODO Auto-generated method stub
		  String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
	        if (!Pattern.matches(nameRegEx, name)) {
	            throw new BAException("first letter should be capital and length must be in between 5 to 10 \n");
	        }
		
	}

	@Override
	public void validateId(int id) throws BAException {
		// TODO Auto-generated method stub
		String idRegEx = "[0-9]{3}";
		if (!Pattern.matches(idRegEx, String.valueOf(id))) {
			throw new BAException("id should be 3 digit number \n");
		}
		
	}

	@Override
	public boolean validateAccount(int accountNo) throws BAException {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		String idRegEx = "[0-9]{7}";
		if (!Pattern.matches(idRegEx, String.valueOf(accountNo))) {
			throw new BAException("id should be 7 digit number \n");
		} else {
			resultFlag = true;
		}
		return resultFlag;
		}
	

	@Override
	public boolean isValid(String email) throws BAException {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		 String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";

		if (!Pattern.matches(regex,email)) {
			throw new BAException("email should be in 'abc2xyz.com' format\n");
		} else {
			resultFlag = true;
		}
		return resultFlag;
		 
	}

	@Override
	public boolean validateMobile(long mobileNo) throws BAException {
		// TODO Auto-generated method stub 
		boolean resultFlag = false;
		String idRegEx = "^[7-9][0-9]{9}$";
		if (!Pattern.matches(idRegEx, String.valueOf(mobileNo))) {
			throw new BAException("id should be 10 digit number and start with 7,8 or 9 \n");
		} else {
			resultFlag = true;
		}
		return resultFlag;
		 
		
		
	}

	@Override
	public boolean validateBalance(double balance) throws BAException {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		if (balance <= 0) {
			throw new BAException("balance should not be 0 or less than 0 \n");
		} else {
			resultFlag = true;
		}
		return resultFlag;
		}


	@Override
	public boolean validateAccountNo(int accountNo) throws BAException {
		// TODO Auto-generated method stub
		boolean flag = false;
		Customer customer = em.find(Customer.class, accountNo);
		if(customer!= null) {
			flag = true;
		}
		else {
			flag= false;
			throw new BAException("Entered accountNo is invalid");
		}
		return flag;
	}

	@Override
	public double showBalance(int accountNo) throws BAException {
		// TODO Auto-generated method stub
		return dao.showBalance(accountNo);
	}

	}


