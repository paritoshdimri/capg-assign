package com.capgemini.bankapplication.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customer1")
public class Customer{
	@Id
	private int accountNo;
	private String CustomerName;
	private String address;
	private String email;
	private long mobileNo;
	protected double balance;
	//List<Transaction> transactions;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public Customer(int accountNo,  String customerName, String address, String email, long mobileNo,
		double balance) {
		super();
		this.accountNo = accountNo;
		CustomerName = customerName;
		this.address = address;
		this.email = email;
		this.mobileNo = mobileNo;
		this.balance = balance;
		
	}

	
	

	public Customer(String customerName, String address, String email, long mobileNo, double balance) {
		super();
		CustomerName = customerName;
		this.address = address;
		this.email = email;
		this.mobileNo = mobileNo;
		this.balance = balance;
	}

	
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	/*public List<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}*/
	@Override
	public String toString() {
		return "Customer [accountNo=" + accountNo + ", CustomerName=" + CustomerName
				+ ", address=" + address + ", email=" + email + ", mobileNo=" + mobileNo + ", balance=" + balance
				/*+ ", transactions=" + transactions*/ + "]";
	}
	

}
