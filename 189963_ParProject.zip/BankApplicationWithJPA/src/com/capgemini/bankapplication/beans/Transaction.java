package com.capgemini.bankapplication.beans;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "transactions")
public class Transaction {
	@Id
	private int TransactionId;
	private String transactionType;
	private Date transactionDate;
	private int accountNo;
	private int destinationAccNo;
	private double amount;
	
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Transaction(String transactionType, Date transactionDate,int accountNo,
			int destinationAccNo,double amount) {
		super();
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.accountNo = accountNo;
		this.destinationAccNo = destinationAccNo;
		this.amount=amount;
		
	}
	

	public Transaction(int transactionId, String transactionType, Date transactionDate,int accountNo,
			int destinationAccNo,double amount) {
		super();
		TransactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.accountNo = accountNo;
		this.destinationAccNo = destinationAccNo;
		this.amount=amount;
		
	}
	

	public Transaction( int accountNo, int destinationAccNo, double amount) {
		super();
		
		this.accountNo = accountNo;
		this.destinationAccNo = destinationAccNo;
		this.amount=amount;
		
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public int getTransactionId() {
		return TransactionId;
	}
	public void setTransactionId(int transactionId) {
		TransactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transDate) {
		this.transactionDate = transDate;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public long getDestinationAccNo() {
		return accountNo;
	}
	public void setDestinationAccNo(int destinationAccNo) {
		this.destinationAccNo = destinationAccNo;
	}
	

	@Override
	public String toString() {
		return "Transaction [TransactionId=" + TransactionId + ", transactionType=" + transactionType
				+ ", transactionDate=" + transactionDate + ", accountNo=" + accountNo
				+ ", destinationAccNo=" + destinationAccNo + ", amount=" + amount + "]";
	}
	
	

}
