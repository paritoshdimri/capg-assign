package com.capgemini.bankapplication.dao;

import java.util.List;
import java.util.Map;

import com.capgemini.bankapplication.beans.Customer;
import com.capgemini.bankapplication.beans.Transaction;
import com.capgemini.bankapplication.exception.BAException;

public interface BankApplicationDAO {
	public int createAccount(Customer customer) throws BAException;
	public double deposit(int accountNo,double amountToDeposit) throws BAException;
	public double withdraw(int accountNo, double amountToWithdraw) throws BAException;
	public List<Customer> printCustomers(int accountNo) throws BAException;
	public int fundTransfer(int accountNo, int destinationAccNo,double amount) throws BAException;
	public double showBalance(int accountNo) throws BAException;
	public List<Transaction> printTransactions(int accountNo) throws BAException;
	
}
