package com.capgemini.bankapplication.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.capgemini.bankapplication.beans.Customer;
import com.capgemini.bankapplication.beans.Transaction;
import com.capgemini.bankapplication.exception.BAException;

public class BankApplicationDAOImpl implements BankApplicationDAO {
    boolean status=false;
    EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();
	public int createAccount(Customer customer) {
		
		int accountNo = (int) (Math.random() * 1000);
		customer.setAccountNo(accountNo);

		em.getTransaction().begin();
		em.persist(customer);
		em.getTransaction().commit();
		System.out.println("Succesfully registered!! Your AccountNo is " + accountNo);
		return accountNo;
	}

	@Override
	public double deposit(int accountNo, double amountToDeposit) {
		double updatedBalance = 0.0;
		em.getTransaction().begin();
		Customer customer = em.find(Customer.class, accountNo);
		if (customer != null) {
			updatedBalance = customer.getBalance() + amountToDeposit;
			customer.setBalance(updatedBalance);

			Transaction transaction = new Transaction();
			int transId = (int) (Math.random() * 10000);
			java.util.Date transDate = new java.util.Date();
			transaction.setTransactionId(transId);
			transaction.setTransactionType("Credit");
			transaction.setTransactionDate(transDate);
			transaction.setAccountNo(accountNo);
			transaction.setAmount(amountToDeposit);
			transaction.setDestinationAccNo(accountNo);
			em.persist(transaction);

			em.getTransaction().commit();
		}
		return updatedBalance;
	}

	@Override
	public double withdraw(int accountNo, double amountToWithdraw) {
		double updatedBalance = 0.0;
		em.getTransaction().begin();
		Customer customer = em.find(Customer.class, accountNo);
		if (customer != null && customer.getBalance() > amountToWithdraw) {
			updatedBalance = customer.getBalance() - amountToWithdraw;
			customer.setBalance(updatedBalance);

			Transaction transaction = new Transaction();
			int transId = (int) (Math.random() * 10000);
			java.util.Date transDate = new java.util.Date();
			transaction.setTransactionId(transId);
			transaction.setTransactionType("Debit");
			transaction.setTransactionDate(transDate);
			transaction.setAmount(amountToWithdraw);
			transaction.setAccountNo(accountNo);
			transaction.setDestinationAccNo(accountNo);
			em.persist(transaction);
			em.getTransaction().commit();
		} else {
			System.err.println("Insufficient balance!");
		}
		return updatedBalance;

	}

	@Override
	public List<Customer> printCustomers(int accountNo) {
		TypedQuery<Customer> query = em.createQuery("from customer1 where accountNo=:accountNo",
				Customer.class);
		query.setParameter("accountNo", accountNo);
		List<Customer> customerList = query.getResultList();
		return customerList;
		
	}

	

	@Override
	public int fundTransfer(int accountNo, int destinationAccNo, double amount) throws BAException {
		double updatedAmountofPayee = 0.0;
		double updatedAmountofRecepient = 0.0;
		int transId = (int) (Math.random() * 10000);
		em.getTransaction().begin();
		Customer payeeCustomer = em.find(Customer.class, accountNo);
		Customer recepientCustomer = em.find(Customer.class, destinationAccNo);
		double availableBalance = payeeCustomer.getBalance();
		if (payeeCustomer != null && recepientCustomer != null && payeeCustomer.getBalance() > amount) {

			updatedAmountofPayee = payeeCustomer.getBalance() - amount;
			payeeCustomer.setBalance(updatedAmountofPayee);
			updatedAmountofRecepient = recepientCustomer.getBalance() + amount;
			recepientCustomer.setBalance(updatedAmountofRecepient);

			Transaction transaction = new Transaction();

			java.util.Date transDate = new java.util.Date();
			transaction.setTransactionId(transId);
			if (updatedAmountofPayee > availableBalance) {
				transaction.setTransactionType("Debit");
			} else {
				transaction.setTransactionType("Credit");
			}

			transaction.setTransactionDate(transDate);
			transaction.setAmount(amount);
			transaction.setAccountNo(accountNo);
			transaction.setDestinationAccNo(destinationAccNo);;
			em.persist(transaction);

			em.getTransaction().commit();
		} else {
			System.err.println("Insufficient balance!");
		}

		return transId;
	}
	

	@Override
	public List<Transaction> printTransactions(int accountNo) {
		// TODO Auto-generated method stub
		TypedQuery<Transaction> query = em.createQuery("from transactions where accountNo=:accNo",
				Transaction.class);
		query.setParameter("accNo", accountNo);
		List<Transaction> transactionList = query.getResultList();
		return transactionList;
	}

	@Override
	public double showBalance(int accountNo) throws BAException {
		em.getTransaction().begin();
		Customer customer = em.find(Customer.class, accountNo);
		em.getTransaction().commit();
		return customer.getBalance();
	}


}