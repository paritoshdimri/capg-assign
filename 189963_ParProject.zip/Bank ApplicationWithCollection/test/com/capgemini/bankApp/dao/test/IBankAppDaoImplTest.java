package com.capgemini.bankApp.dao.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.bankApp.bean.Customer;
import com.capgemini.bankApp.bean.Transaction;
import com.capgemini.bankApp.dao.BankAppDAOImpl;
import com.capgemini.bankApp.exception.BankAppException;

public class IBankAppDaoImplTest {
	 static Customer customer;
	 static Transaction transaction;
	 static BankAppDAOImpl bankDao;
	
	@Before
	public void setUp() throws Exception {
		customer = new Customer();
        transaction = new Transaction();
		bankDao= new BankAppDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		
		customer=null;
        transaction=null;
        bankDao=null;
		
	}

	@Test
	public void testCreateAccount() {
		Customer customer= new Customer("Mrk", "aa@aa.in", "9898989898", "ghh", 56789d);
        try {
            int genId= bankDao.createAccount(customer);
            assertNotNull(genId);
        } catch (BankAppException e) {
        }
	}
	
	@Test
	public void testCreateAccountNull() {
		Customer customer= new  Customer("Mrk", "aa@aa.in", "9898989898", "ghh", 56789d);

		try {
            int genId= bankDao.createAccount(customer);
            assertNull(genId);
        } catch (BankAppException e) {

        }
 }

	@Test
	public void testShowBalance() {
		Customer customer= new Customer("Mrk", "aa@aa.in", "9898989898", "ghh", 56789d);
		try {
			int genId= bankDao.createAccount(customer);
            double balance = bankDao.showBalance(genId);
            assertTrue(balance>=0.0);
        } catch (BankAppException e) {
        }
	}
	
	@Test
	public void testShowBalanceNull() {
		Customer customer= new Customer("Mrk", "aa@aa.in", "9898989898", "ghh", 56789d);
		try {
			int genId= bankDao.createAccount(customer);
            double balance = bankDao.showBalance(genId);
            assertNull(balance);
        } catch (BankAppException e) {
        }
	}

	@Test
	public void testDeposit() {
		Customer customer= new Customer("Mrk", "aa@aa.in", "9898989898", "ghh", 56789d);
		try {
			int genId= bankDao.createAccount(customer);
            double balance = bankDao.deposit(genId, 1000);
            assertTrue(balance>=0.0);
        } catch (BankAppException e) {
        	
        }      
	}
	
	@Test
	public void testDepositNull() {
		try {
            double customer = bankDao.deposit(333, 1000);
            assertNull(customer);
        } catch (BankAppException e) {
        }      
	}

	@Test
	public void testWithdraw() {
		try {
            double customer = bankDao.withdraw(333, 1000);
            assertNotNull(customer);
        } catch (BankAppException e) {
        } 
	}
	
	@Test
	public void testWithdrawNull() {
		try {
            double customer = bankDao.withdraw(333, 1000);
            assertNull(customer);
        } catch (BankAppException e) {
        } 
	}

	@Test
	public void testFundTransfer() {
		try {
            String customer = bankDao.fundTransfer(111, 222, 1500, "credit");
            assertNotNull(customer);
        } catch (BankAppException e) {
        }	
		}
	
	
	@Test
	public void testFundTransferNull() {
		try {
            String customer = bankDao.fundTransfer(111, 222, 1500, "credit");
            assertNull(customer);
        } catch (BankAppException e) {
        }	
		}

	@Test
	public void testSearchCustomer() {
		try {
            Customer customer = bankDao.searchCustomer(111);
            assertNotNull(customer);
        } catch (BankAppException e) {
        }
	}
	
	@Test
	public void testSearchCustomerNull() {
		try {
            Customer customer = bankDao.searchCustomer(111);
            assertNull(customer);
        } catch (BankAppException e) {
        }
	}

	@Test
	public void testTransactions() {
		List<Transaction> list;
        try {
            list = bankDao.transactions(111);
            assertNotNull(list);
        } catch (BankAppException e) {
            // TODO Auto-generated catch block
            System.out.println(e.getMessage());
        }   
	}
	
	@Test
	public void testTransactionsNull() {
		List<Transaction> list;
        try {
            list = bankDao.transactions(111);
            assertNull(list);
        } catch (BankAppException e) {
            // TODO Auto-generated catch block
            System.out.println(e.getMessage());
        }   
	}

}
