package com.capgemini.bankApp.bean;

import java.util.List;

public class Customer {
	private int customerId;
	private String name;
	private String email;
	private String mobile;
	private String address;
	private int accountNo;
	private double balance;
	List<Transaction> transactions;
	
	public Customer() {
		super();
	}
	public Customer(int customerId, String name, String email, String mobile, String address, int accountNo,
			double balance, List<Transaction> transactions) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.address = address;
		this.accountNo = accountNo;
		this.balance = balance;
		this.transactions = transactions;
	}
	
	
	public Customer(String name, String email, String mobile, String address, double balance) {
		super();
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.address = address;
		this.balance = balance;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public List<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", name=" + name + ", email=" + email + ", mobile=" + mobile
				+ ", address=" + address + ", accountNo=" + accountNo + ", balance=" + balance +", Transactions"+ transactions+"]";
	}
	
}
