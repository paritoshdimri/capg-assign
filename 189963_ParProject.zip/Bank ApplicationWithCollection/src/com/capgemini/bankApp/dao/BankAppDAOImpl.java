package com.capgemini.bankApp.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.bankApp.bean.Customer;
import com.capgemini.bankApp.bean.Transaction;
import com.capgemini.bankApp.exception.BankAppException;

public class BankAppDAOImpl implements IBankAppDAO {
	static int accId= 1000;
	@Override
	public int createAccount(Customer customer) throws BankAppException {
		int custId= (int)(Math.random()*1000);
		customer.setCustomerId(custId);
		accId+=1;
		customer.setAccountNo(accId);
		map.put(accId, customer);
		return accId;
	}

	@Override
	public double showBalance(int accountNo) throws BankAppException {
		Customer customer= map.get(accountNo);
		return customer.getBalance();
	}

	@Override
	public double deposit(int accountNo, int amount) throws BankAppException {
		Customer customer= map.get(accountNo);
		int transId= (int)(Math.random()*1000);
		DateFormat df2= new SimpleDateFormat("dd/MM/yy");
		java.util.Date date= new java.util.Date();
		String transDate1= " ";
		transDate1= df2.format(date);
		Transaction trans= new Transaction(transId, "credit", transDate1, customer.getCustomerId(), customer.getAccountNo(), amount);
		if(customer!=null)
		{
			double balance= customer.getBalance()+amount;
		customer.setBalance(balance);
		return customer.getBalance();
		}
		return 0.0;
			
	}

	@Override
	public double withdraw(int accountNo, int amount) throws BankAppException {
		Customer customer= map.get(accountNo);
		int transId= (int)(Math.random()*1000);
		DateFormat df2= new SimpleDateFormat("dd/MM/yy");
		java.util.Date date= new java.util.Date();
		String transDate1= " ";
		transDate1= df2.format(date);
		Transaction trans= new Transaction(transId, "debit", transDate1, customer.getCustomerId(), customer.getAccountNo(), amount);
		if(customer!=null && customer.getBalance()>=amount)
		{
		double balance= customer.getBalance()-amount;
		customer.setBalance(balance);
		return customer.getBalance();
		}
		else {
			return 0.0;
		}
	}

	@Override
	public String fundTransfer(int destAccountNo, int srcAccountNo, int amount, String transType) throws BankAppException {
		Customer customer1= map.get(destAccountNo);
		Customer customer2= map.get(srcAccountNo);
		double balance1=0;
		double balance2=0;
		String transType2="";
		if(customer1!=null && customer2!=null && customer2.getBalance()>amount)
		{
		if(transType.equals("credit"))
		{
			balance1= customer1.getBalance()+amount;
		    balance2= customer2.getBalance()-amount;
		}
		else {
			balance1= customer1.getBalance()-amount;
			balance2= customer2.getBalance()+amount;
		}
		customer1.setBalance(balance1);
		customer2.setBalance(balance2);
		int transId= (int)(Math.random()*1000);
		DateFormat df2= new SimpleDateFormat("dd/MM/yy");
		java.util.Date date= new java.util.Date();
		String transDate1= " ";
		transDate1= df2.format(date);
		if(transType.equals("credit")) {
			transType2= "debit";
		}
		Transaction transaction1= new Transaction(transId, transType, transDate1, customer1.getCustomerId(), customer1.getAccountNo(), amount);
		Transaction transaction2= new Transaction(transId, transType2, transDate1, customer2.getCustomerId(), customer2.getAccountNo(), amount);
		List<Transaction> trans1= new ArrayList<>();
		trans1.add(transaction1);
		customer1.setTransactions(trans1);
		List<Transaction> trans2= new ArrayList<>();
		trans2.add(transaction2);
		customer2.setTransactions(trans2);
		return "transaction successful";
		}
		else
			{return null;}
		
	}

	@Override
	public Customer searchCustomer(int accountNo) throws BankAppException {
		// TODO Auto-generated method stub
		return map.get(accountNo);
	}

	@Override
	public List<Transaction> transactions(int accountNo) throws BankAppException {
		Customer customerdata= map.get(accountNo);
		if(customerdata.getTransactions()!=null) {
		return customerdata.getTransactions();
		}
		else
			{return null;}
	}

}
