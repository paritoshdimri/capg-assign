package com.capgemini.bankApp.dao;

import java.util.HashMap;
import java.util.List;

import com.capgemini.bankApp.bean.Customer;
import com.capgemini.bankApp.bean.Transaction;
import com.capgemini.bankApp.exception.BankAppException;

public interface IBankAppDAO {
	public int createAccount(Customer customer) throws BankAppException;
	public double showBalance(int accountNo) throws BankAppException;
	public double deposit(int accountNo, int amount) throws BankAppException;
	public double withdraw(int accountNo, int amount) throws BankAppException;
	public String fundTransfer(int destAccountNo, int srcAccountNo, int amount, String transType) throws BankAppException;
	public List<Transaction> transactions(int accountNo) throws BankAppException;
	Customer searchCustomer(int accountNo) throws BankAppException;
	HashMap<Integer, Customer> map= new HashMap<>();
}
