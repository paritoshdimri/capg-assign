package com.capgemini.bankApp.service;

import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.bankApp.bean.Customer;
import com.capgemini.bankApp.bean.Transaction;
import com.capgemini.bankApp.dao.BankAppDAOImpl;
import com.capgemini.bankApp.dao.IBankAppDAO;
import com.capgemini.bankApp.exception.BankAppException;

public class BankAppServiceImpl implements IBankAppService {
	
	IBankAppDAO daoimpl= new BankAppDAOImpl();
	
	@Override
	public int createAccount(Customer customer) throws BankAppException {
		if(daoimpl.createAccount(customer)==-1) {
			throw new BankAppException("Account cannot be created");
		}
		return daoimpl.createAccount(customer);
	}

	@Override
	public double showBalance(int accountNo) throws BankAppException {
		return daoimpl.showBalance(accountNo);
	}

	@Override
	public double deposit(int accountNo, int amount) throws BankAppException {
		return daoimpl.deposit(accountNo, amount);
	}

	@Override
	public double withdraw(int accountNo, int amount) throws BankAppException {
		if(daoimpl.showBalance(accountNo) < amount) {
			throw new BankAppException("Insufficient balance");
		}
		return daoimpl.withdraw(accountNo, amount);
	}

	@Override
	public String fundTransfer(int destAccountNo, int srcAccountNo, int amount, String transType)
			throws BankAppException {
		if(daoimpl.fundTransfer(destAccountNo, srcAccountNo, amount, transType)==null) {
			throw new BankAppException("Invalid account number or insufficient balance");
		}
		return daoimpl.fundTransfer(destAccountNo, srcAccountNo, amount, transType);
	}

	@Override
	public Customer searchCustomer(int accountNo) throws BankAppException {
		
		if(daoimpl.searchCustomer(accountNo)==null) {
			throw new BankAppException("Customer not found");
		}
		return daoimpl.searchCustomer(accountNo);
	}

	@Override
	public void validateName(String name) throws BankAppException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (!Pattern.matches(nameRegEx, name)) {
			throw new BankAppException("first letter should be capital and length must be in between 5 to 10 \n");
		}
		
	}

	@Override
	public void validateEmail(String email) throws BankAppException {
		String emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}";
		if (!Pattern.matches(emailRegEx, email)) {
			throw new BankAppException("email Id should be in the format abc@xyz.com \n");
		}
	}

	@Override
	public void validateMobile(String mobile) throws BankAppException {
		String mobRegEx = "[0-9]{10}";
		if (!Pattern.matches(mobRegEx, mobile)) {
			throw new BankAppException("mobile number should start from 7, 8, or 9 and should be of 10 digits \n");
		}
	}

	@Override
	public List<Transaction> transations(int accountNo) throws BankAppException {
		if(daoimpl.transactions(accountNo)==null) {
			throw new BankAppException("No transactions found");
		}
		return daoimpl.transactions(accountNo);
	}

}
