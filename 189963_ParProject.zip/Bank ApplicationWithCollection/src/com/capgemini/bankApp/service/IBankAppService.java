package com.capgemini.bankApp.service;

import java.util.List;

import com.capgemini.bankApp.bean.Customer;
import com.capgemini.bankApp.bean.Transaction;
import com.capgemini.bankApp.exception.BankAppException;

public interface IBankAppService {
	public int createAccount(Customer customer) throws BankAppException;
	public double showBalance(int accountNo) throws BankAppException;
	public double deposit(int accountNo, int amount) throws BankAppException;
	public double withdraw(int accountNo, int amount) throws BankAppException;
	public String fundTransfer(int destAccountNo, int srcAccountNo, int amount, String transType) throws BankAppException;
	Customer searchCustomer(int accountNo) throws BankAppException;
	public List<Transaction> transations(int accountNo) throws BankAppException;
	public void validateName(String name) throws BankAppException;
	public void validateEmail(String email) throws BankAppException;
	public void validateMobile(String mobile) throws BankAppException;
}
