package com.capgemini.bankApp.presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.bankApp.bean.Customer;
import com.capgemini.bankApp.exception.BankAppException;
import com.capgemini.bankApp.service.BankAppServiceImpl;
import com.capgemini.bankApp.service.IBankAppService;

public class MainUI {

	public static void main(String[] args) {

		Scanner scanner = null;

		IBankAppService service = new BankAppServiceImpl();

		String continueChoice = "";
		boolean continueValue = false;

		do {
			System.out.println("------ Welcome to World Bank ------");
			System.out.println("1. To Create an Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Withdraw Balance");
			System.out.println("4. Deposit Amount");
			System.out.println("5. Fund Transfer ");
			System.out.println("6. To Print Transactions");
			System.out.println("7. Exit");
			System.out.println("-----------------------------------");

			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					switch (choice) {

					case 1: {

						String name = "";
						boolean nameFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter customer name");
							try {
								name = scanner.nextLine();
								service.validateName(name);
								nameFlag = true;
								break;
							} catch (BankAppException e) {
								// TODO Auto-generated catch block
								nameFlag = false;
								System.out.println(e.getMessage());
							}
						} while (!nameFlag);

						String email = "";
						boolean emailFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter email");
							try {
								email = scanner.nextLine();
								service.validateEmail(email);
								emailFlag = true;
								break;
							} catch (BankAppException e) {
								emailFlag = false;
								System.out.println(e.getMessage());
							}
						} while (!emailFlag);

						String mobile = "";
						boolean mobileFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter mobile number");
							try {
								mobile = scanner.nextLine();
								service.validateMobile(mobile);
								mobileFlag = true;
								break;
							} catch (BankAppException e) {
								mobileFlag = false;
								System.out.println(e.getMessage());
							}
						} while (!mobileFlag);

						scanner = new Scanner(System.in);
						System.out.println("Enter address");
						String address = scanner.nextLine();
						scanner = new Scanner(System.in);
						System.out.println("Enter balance");
						double balance = scanner.nextDouble();

						Customer customer = new Customer(name, email, mobile, address, balance);
						try {
							int generatedaccId = service.createAccount(customer);
							System.out.println("Account number is " + generatedaccId);
						} catch (BankAppException e) {
							System.out.println(e.getMessage());
						}
					}

						break;

					case 2:

						int accNo = 0;
						boolean accNoFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter account no.:");
							try {
								accNo = scanner.nextInt();
								accNoFlag = true;
								double balance;
								try {
									balance = service.showBalance(accNo);
									System.out.println("The account balance after deposit is " + balance);
								} catch (BankAppException e) {
									System.err.println(e.getMessage());
								}

							} catch (InputMismatchException e) {
								accNoFlag = false;
								System.err.println("Account no. should be in digits");
							}
						} while (!accNoFlag);

						break;

					case 3:
						int accNo1 = 0;
						boolean accNoFlag1 = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter account no.:");
							try {
								accNo1 = scanner.nextInt();
								accNoFlag1 = true;
								int amount = 0;
								double balance;
								System.out.println("Enter amount to withdraw:");
								try {
									amount = scanner.nextInt();
									balance = service.withdraw(accNo1, amount);
									System.out.println("Account balance after withdrawl = " + balance);
								} catch (BankAppException e) {
									System.err.println(e.getMessage());
								}

							} catch (InputMismatchException e) {
								accNoFlag1 = false;
								System.err.println("Account no. should be in digits");
							}
						} while (!accNoFlag1);

						break;

					case 4:
						int accNo2 = 0;
						boolean accNoFlag2 = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter account no.:");
							try {
								accNo2 = scanner.nextInt();
								accNoFlag2 = true;
								int amount = 0;
								double balance;
								System.out.println("Enter amount to deposit:");
								try {
									amount = scanner.nextInt();
									balance = service.deposit(accNo2, amount);
									System.out.println(balance);
								} catch (BankAppException e) {
									System.err.println(e.getMessage());
								}

							} catch (InputMismatchException e) {
								accNoFlag2 = false;
								System.err.println("Account no. should be in digits");
							}
						} while (!accNoFlag2);

						break;

					case 5:
						int destaccNo = 0;
						int sourceaccNo = 0;
						boolean accFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter your account no.:");
							try {
								sourceaccNo = scanner.nextInt();
								System.out.println("Enter destination account no.:");
								destaccNo = scanner.nextInt();
								accFlag = true;
								int amount = 0;
								System.out.println("Enter amount to transfer:");
								try {
									amount = scanner.nextInt();
									// balance = service.withdraw(accNo2, amount);
									System.out.println(service.fundTransfer(destaccNo, sourceaccNo, amount, "credit"));
								} catch (BankAppException e) {
									System.err.println(e.getMessage());
								}

							} catch (InputMismatchException e) {
								accNoFlag2 = false;
								System.err.println("Account no. should be in digits");
							}
						} while (!accFlag);

						break;

					case 6:
						int accNo3 = 0;
						boolean accNoFlag3 = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter account no.:");
							try {
								accNo3 = scanner.nextInt();
								accNoFlag3 = true;
								// List<Transaction> list= new ArrayList<>();
								try {
									System.out.println(service.transations(accNo3));
								} catch (BankAppException e) {
									System.err.println(e.getMessage());
								}

							} catch (InputMismatchException e) {
								accNoFlag3 = false;
								System.err.println("Account no. should be in digits");
							}
						} while (!accNoFlag3);

						break;

					case 7:
						System.out.println("*** Thank you *** ");
						System.exit(0);
						break;

					default:
						choiceFlag = false;
						System.out.println("Input should be 1, 2 or 3");
						break;
					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("Please enter only digits");
				}

			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("Do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("-----Thank you-----");
					continueValue = false;
					break;
				} else {
					System.out.println("Enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);
		} while (continueValue);
		scanner.close();
	}

}
