package com.capgemini.bankapplication.service;

import java.util.List;
import java.util.Map;

import com.capgemini.bankapplication.beans.Customer;
import com.capgemini.bankapplication.beans.Transaction;
import com.capgemini.bankapplication.exception.BAException;

public interface BankApplicationService {
	public int createAccount(Customer customer) throws BAException;
	public boolean deposit(int accountNo,double amountToDeposit) throws BAException;
	public boolean withdraw(int accountNo, double amountToWithdraw) throws BAException;
	public boolean printCustomers(int accountNo) throws BAException;
	public int fundTransfer(int accountNo,int destinationAccNo, double amount) throws BAException;
	double showBalance(int accountNo) throws BAException;
	public boolean printTransactions(int accountNo) throws BAException;
	public void validateName(String name) throws BAException;
	public boolean validateMobile(long mobileNo) throws BAException;
	public void validateId(int id) throws BAException;
	public boolean validateAccount(int accountNo) throws BAException;
	public boolean isValid(String email) throws BAException;
	public boolean validateBalance(double balance) throws BAException;
	public boolean validateAccountNo(int accountNo) throws BAException;
	
}
