package com.capgemini.bankapplication.utility;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.bankapplication.beans.Customer;
import com.capgemini.bankapplication.beans.Transaction;
import com.capgemini.bankapplication.exception.BAException;
import com.capgemini.bankapplication.service.BankApplicationService;
import com.capgemini.bankapplication.service.BankApplicationServiceImpl;

public class MainUI {
	public static void main(String[] args) {
		String continueChoice;
		boolean continueValue = false;

		Scanner scanner = null;
		do {

			System.out.println("*** Welcome to World Bank ***");
			System.out.println("1. Create account");
			System.out.println("2. Deposit");
			System.out.println("3. Withdraw");
			System.out.println("4. Print customer by id");
			System.out.println("5. Fund transfer");
			System.out.println("6. Print transaction by id");
			System.out.println("7. Show Balance");
			System.out.println("8. Exit");

			BankApplicationService service = new BankApplicationServiceImpl();
			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter input:");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean nameFlag = false;

					String name = "";
					switch (choice) {

					case 1:
						
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter name:");
							name = scanner.nextLine();
							try {
								service.validateName(name);
								nameFlag = true;
							} catch (InputMismatchException e) {
								nameFlag = false;
								System.err.println("name should be in string");
							} catch (BAException e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!nameFlag);

						String address="";
						boolean addressFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter address:");
							try {
								address = scanner.nextLine();
							    addressFlag = true;
							} catch (InputMismatchException e) {
								addressFlag = false;
								System.err.println("Address should be in string");
							/*} catch (BAException e) {
								addressFlag = false;
								System.err.println(e.getMessage());*/
							}
						} while (!addressFlag);

						
						String email="";
						boolean mailFlag=false;
						do {
							scanner = new Scanner(System.in);
						System.out.println("Enter email:");
						email = scanner.nextLine();
						try {
							service.isValid(email);
						    mailFlag = true;
						} catch (InputMismatchException e) {
							mailFlag = false;
							System.err.println("email should be in format");
						} catch (BAException e) {
							mailFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!mailFlag);
						long mobileNo=0;
						boolean mobFlag=false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter mobile no:");
							mobileNo = scanner.nextLong();
							try {
								service.validateMobile(mobileNo);
								mobFlag = true;
							} catch (InputMismatchException e) {
								mobFlag = false;
								System.err.println("mobileNo should be in digits");
							} catch (BAException e) {
								mobFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!mobFlag);
						double balance=0.0;
						boolean balFlag=false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter balance:");
							
							try {
								balance = scanner.nextInt();
								service.validateBalance(balance);
								balFlag = true;
							} catch (InputMismatchException e) {
								mailFlag = false;
								System.err.println("Balance should be in digits");
							} catch (BAException e) {
								balFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!balFlag);
						

						Customer customer = new Customer(name, address, email, mobileNo, balance);
						try {
							int genearatedId = service.createAccount(customer);
							System.out.println("customer information stored with the given id: " + genearatedId);
						} catch (BAException e) {
							System.err.println(e.getMessage());
						}

						break;
						
					case 2:
						boolean flag = false;
						do{
							System.out.println("Enter accountNo to deposit money");
							int accountNo= scanner.nextInt();
							System.out.println("Enter amount to deposit");
							int amountToDeposit=scanner.nextInt();
							try {
								boolean status = service.deposit(accountNo, amountToDeposit);
								if (status) {
									System.out.println("deposited successfully");
									flag=true;
								} 
							}
							catch (InputMismatchException e) {
								 boolean status = false;
								flag=false;
								System.err.println("vehicleid should be digits");
							}
							 catch (BAException e) {
									// TODO: handle exception
								 flag=false;
									System.out.println(e.getMessage());
								}
						} while(!flag);
						break;
						
						
					case 3:
						boolean flag1 = false;
						do{ scanner = new Scanner(System.in);
						try {System.out.println("Enter accountNo to withdraw money");
							int accountNo= scanner.nextInt();
							service.validateAccountNo(accountNo);
							System.out.println("Enter amount to withdraw");
							int amountToWithdraw=scanner.nextInt();
							
								boolean status = service.withdraw(accountNo, amountToWithdraw);
								if (status) {
									System.out.println("withdrawed successfully");
									flag1=true;
								} 
							}
							catch (InputMismatchException e) {
								 boolean status = false;
								flag1=false;
								System.err.println("It should be in digits");
							}
							 catch (BAException e) {
									// TODO: handle exception
								 flag1=false;
									System.out.println(e.getMessage());
								}
						} while(!flag1);
						break;

				
					case 4: boolean Idflag1=false;
					do{
						
						System.out.println("Enter accountNo to view customer");
						int accountNo= scanner.nextInt();
						try {
							boolean status = service.printCustomers(accountNo);
							if (status) {
								//System.out.println(service.printCustomers(accountNo));
								Idflag1=true;
							} 
						}catch (InputMismatchException e) {
							 boolean status = false;
							Idflag1=false;
							System.err.println("accountNo should be digits");
						}
						catch (BAException e) {
							// TODO: handle exception
							Idflag1=false;
							System.out.println(e.getMessage());
						}
					}while (!Idflag1);

						break;
						
					case 5: {
						int accountNo;
					boolean customerFlag = false;

					do {

						scanner = new Scanner(System.in);

						try {

							System.out.println("Enter your Account Number: ");
							accountNo = scanner.nextInt();
							System.out.println("Enter destination Account Number: ");
							int destinationAccNo = scanner.nextInt();
							System.out.println("Enter amount to transfer");
							double amount = scanner.nextDouble();

							Transaction transaction = new Transaction(accountNo, destinationAccNo, amount);

							int transfer = service.fundTransfer(accountNo, destinationAccNo, amount);

							System.out.println("Amount transfered!");
							System.out.println("Your transaction id is : " + transfer);

							customerFlag = true;
							break;

						} catch (BAException e) {

							customerFlag = false;
							System.err.println(e.getMessage());
						}

					} while (!customerFlag);
					}
					break;
					
						
					case 6:
						boolean Idflag=false;
					do{
						
						System.out.println("Enter accountNo to view transaction");
						int accountNo= scanner.nextInt();
						try {
							boolean status = service.printTransactions(accountNo);
							if (status) {
								//System.out.println(service.printTransactions(accountNo));
								Idflag=true;
							} 
						}catch (InputMismatchException e) {
							 boolean status = false;
							Idflag=false;
							System.err.println("accountNo should be digits");
						}
						catch (BAException e) {
							// TODO: handle exception
							Idflag=false;
							System.out.println(e.getMessage());
						}
					}while (!Idflag);

						break;
					
						
					case 7: int accountNo;
						boolean customerFlag = false;

						do {
							Customer customer1 = new Customer();
							scanner = new Scanner(System.in);
							System.out.println("Enter your Account Number: ");

							try {
								accountNo = scanner.nextInt();
								// bankService.validateAccount(customerAccountNumber);
								double balance1 =service.showBalance(accountNo);

								System.out.println("Your current balance is :" + balance1);

								customerFlag = true;
								break;

							} catch (BAException e) {
								customerFlag = false;
								System.err.println(e.getMessage());
							}

						} while (!customerFlag);
						break;

						
					case 8:
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;
					default:
						System.out.println("input should be from 1-8");
						choiceFlag = false;
						break;
					}

				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}
			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (continueValue);
		scanner.close();
	}


}
