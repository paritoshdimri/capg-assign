package com.capgemini.bankapplication.exception;

public class BAException extends Exception {

	private static final long serialVersionUID = 1L;

	public BAException(String message) {
		super(message);
	}

}
