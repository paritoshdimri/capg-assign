package com.capgemini.bankapplication.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import com.capgemini.bankapplication.beans.Customer;
import com.capgemini.bankapplication.beans.Transaction;
import com.capgemini.bankapplication.exception.BAException;
import com.capgemini.bankapplication.presentation.DbConnection;

public class BankApplicationDAOImpl implements BankApplicationDAO {
	PreparedStatement statement = null;
	ResultSet resultSet = null;
	int row = -1;

	@Override
	public int createAccount(Customer customer) throws BAException {
		int accountNo = 0;

		try (Connection connection = DbConnection.getConnection();) {

			statement = connection.prepareStatement("select banksequence1.NEXTVAL from dual");
			resultSet = statement.executeQuery();

			if (resultSet.next()) {

				accountNo= resultSet.getInt(1);
				statement = connection.prepareStatement("insert into bank values(?,?,?,?,?,?)");
				statement.setInt(1, accountNo);
				statement.setString(2, customer.getCustomerName());
				statement.setString(3, customer.getAddress());
				statement.setString(4, customer.getEmail());
				statement.setLong(5, customer.getMobileNo());
				statement.setDouble(6, customer.getBalance());
				row = statement.executeUpdate();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return accountNo;
	}

	@Override
	public boolean deposit(int accountNo, double amountToDeposit) throws BAException {
		Connection connection = DbConnection.getConnection();
		double originalBalance = 0, updatedBalance = 0;
		boolean status=false;
		try {
			statement = connection.prepareStatement("select balance from bank where accountNo=?");
			statement.setLong(1, accountNo);
			ResultSet rs = statement.executeQuery();
			
			while (rs.next()) {
				status=true;
				
				originalBalance = rs.getLong(1);
				statement = connection.prepareStatement("update bank set balance=? where accountNo=?");
				
				updatedBalance = originalBalance + amountToDeposit;
				
				statement.setDouble(1, updatedBalance);
				statement.setLong(2, accountNo);
				statement.executeUpdate();
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public boolean withdraw(int accountNo, double amountToWithdraw) throws BAException {
		Connection connection = DbConnection.getConnection();
		double originalBalance = 0, updatedBalance = 0;
		boolean status=false;
		
		try {
			statement = connection.prepareStatement("select balance from bank where accountNo=?");
			statement.setLong(1, accountNo);
			ResultSet rs = statement.executeQuery();
			
			while (rs.next()) {
				status=true;
				originalBalance = rs.getLong(1);
				statement = connection.prepareStatement("update bank set balance=? where accountNo=?");
				if(originalBalance>amountToWithdraw) {
				updatedBalance = originalBalance - amountToWithdraw;
				
				statement.setDouble(1, updatedBalance);
				statement.setLong(2, accountNo);
				statement.executeUpdate();
				
			} else {
				status=false;
				System.err.println("Insufficient Balance");
			}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}


	@Override
	public boolean printCustomers(int accountNo) throws BAException {
		Connection connection = DbConnection.getConnection();

		try {
			statement = connection.prepareStatement("select * from bank where accountNo=?");
			statement.setLong(1, accountNo);
			ResultSet rs = statement.executeQuery();

			if (rs.next()) {

				System.out.println("AccountNo : " + rs.getInt(1));
				System.out.println("CustomerName : " + rs.getString(2));
				System.out.println("Address : " + rs.getString(3));
				System.out.println("Email : " + rs.getString(4));
				System.out.println("MobileNo : " + rs.getLong(5));
				System.out.println("Balance : " + rs.getDouble(6));

				return true;

			} else {
				return false;
			}

		} catch (SQLException e) {
			throw new BAException("Enter correct details.");
		}

	}

	@Override
	public int fundTransfer(int accountNo, int destinationAccNo, double amount) throws BAException {
		int transactionId = 0;
		double updatedBalanceSource = 0;
		double originalBalance = 0;
		double updatedBalanceDestination = 0;

		Customer customer = new Customer();

		try {

			Connection connection = DbConnection.getConnection();

			statement = connection.prepareStatement("select transeq.NEXTVAL from dual");
			resultSet = statement.executeQuery();

			if (resultSet.next()) {

				transactionId = resultSet.getInt(1);
				statement = connection.prepareStatement("insert into transaction values(?,?,?,?,?,?)");
				statement.setInt(1, transactionId);
				statement.setString(2, "transfer");

				SimpleDateFormat sf = new SimpleDateFormat("dd-MM-yy");
				String currentDate = sf.format(new Date());
				statement.setString(3, currentDate);

				statement.setInt(4, accountNo);
				updatedBalanceSource = customer.getBalance() - amount;
				customer.setBalance(updatedBalanceSource);

				statement.setInt(5, destinationAccNo);
				statement.setDouble(6, amount);

				row = statement.executeUpdate();
			}

			statement = connection.prepareStatement("select balance from bank where accountNo=?");
			statement.setInt(1, accountNo);
			ResultSet rs = statement.executeQuery();

			while (rs.next()) {
				if(originalBalance>amount) {

				originalBalance = rs.getInt(1);
				statement = connection.prepareStatement("update bank set balance=? where accountNo=?");

				updatedBalanceSource = originalBalance - amount;

				statement.setDouble(1, updatedBalanceSource);
				statement.setInt(2, accountNo);
				statement.executeUpdate();

			}
			else 
			{ System.err.println("Insufficient Balance"); }}

			statement = connection.prepareStatement("select balance from bank where accountNo=?");
			statement.setInt(1, destinationAccNo);
			ResultSet rs1 = statement.executeQuery();

			while (rs1.next()) {

				originalBalance = rs1.getInt(1);
				statement = connection.prepareStatement("update bank set balance=? where accountNo=?");

				updatedBalanceDestination = originalBalance + amount;

				statement.setDouble(1, updatedBalanceDestination);
				statement.setInt(2, destinationAccNo);
				statement.executeUpdate();

			}

		} catch (SQLException e) {
			throw new BAException("Transaction failed! Enter correct details.");
		}

		return transactionId;
	}

	@Override
	public boolean printTransactions(int accountNo) throws BAException {
		Connection connection = DbConnection.getConnection();

		try {
			statement = connection.prepareStatement("select * from transaction where accountNo=?");
			statement.setInt(1, accountNo);
			ResultSet rs = statement.executeQuery();

			if (rs.next()) {

				System.out.println("Transaction Id : " + rs.getInt(1));
				System.out.println("Transaction Type : " + rs.getString(2));
				System.out.println("Transaction Date : " + rs.getString(3));
				System.out.println("Account Number : " + rs.getInt(4));
				System.out.println("Transferred to Account Number : " + rs.getInt(5));
				System.out.println("Amount transferred : " + rs.getDouble(6));
				

				return true;

			} else {
				return false;
			}

		} catch (SQLException e) {
			throw new BAException("Transaction failed! Enter correct details.");
		}

	}

	@Override
	public double showBalance(int accountNo) throws BAException {
		Connection connection = DbConnection.getConnection();

		double balance = 0;

		try {
			statement = connection.prepareStatement("select balance from bank where accountNo=?");
			statement.setInt(1, accountNo);
			ResultSet rs = statement.executeQuery();

			while (rs.next()) {

				balance = rs.getLong(1);
				statement = connection.prepareStatement("select balance from bank where accountNo=?");
				statement.setInt(1, accountNo);
				statement.executeUpdate();

			}

		} catch (SQLException e) {
			throw new BAException("Transaction failed! Enter correct details.");
		}

		return balance;
	}

	}

	

