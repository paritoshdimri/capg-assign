package Lab_5;

import java.util.Scanner;
public class Lab5_Ex2_Series {
	static int a=1,b=1;
	
	public static void normal_fibo(int n1){
		while(n1 == 0){
			int c=0;
			c=a+b;
			a=b;
			b=c;
			n1--;
		}
		System.out.println("final value ="+b);
	}
	public static void rec_fibo(int n){
		if(n == 0){
			System.out.println("the value ="+b);
		}
		else{
			int c=0;
			c=a+b;
			a=b;
			b=c;
			rec_fibo(n-1);
		}
	}
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		int n = sc.nextInt();
		rec_fibo(n);
		int n1 = sc.nextInt();
		normal_fibo(n1);
		sc.close();
	}

}
