package Lab_5;

import java.util.Scanner;

public class Lab5_Ex1_Traffic {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter 1 for red");
		System.out.println("Enter 2 for yellow");
		System.out.println("Enter 3 for green");
		int ch = sc.nextInt();

		switch (ch) {
		case 1:
			System.out.println("Stop");
			break;
		case 2:
			System.out.println("Ready");
			break;
		case 3:
			System.out.println("Go");

		}
		sc.close();

	}

}
