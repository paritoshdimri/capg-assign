package Lab_5;

public class Lab5_Ex4_ExceptionNull {
	
	public static void main(String[] args) {

		String fname,lname;
		fname= null;
		lname= "suresh";
		if(fname == null || lname == null){
			try{
				throw new Exception("Type a valid name");
			}catch(Exception ex){
				System.out.println("Not a valid name");
				ex.printStackTrace();
			}
		}else
			System.out.println("Valid name "+fname +"  "+lname);
	}

}
