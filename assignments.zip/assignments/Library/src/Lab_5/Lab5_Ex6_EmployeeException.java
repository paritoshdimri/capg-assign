package Lab_5;

import java.util.Scanner;

public class Lab5_Ex6_EmployeeException {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int salary = sc.nextInt();

		if (salary < 3000) {
			try{
				throw new Exception("dwsad");
				
			}catch(Exception ex){
				System.out.println("Not a valid salary");
				ex.printStackTrace();
			}

		} else
			System.out.println("Valid");
	}
}
