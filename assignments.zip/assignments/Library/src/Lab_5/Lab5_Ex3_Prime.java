package Lab_5;

import java.util.Scanner;

public class Lab5_Ex3_Prime {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();

		for (int i = 2; i <= n; i++) {
			boolean ischeck = true;
			for (int j = 2; j < i; j++) {
				if (i % j == 0) {
					ischeck = false;
					break;
				}
			}
			if (ischeck == true)
				System.out.println("Prime numbers are = " + i);
		}
		sc.close();
	}
}
