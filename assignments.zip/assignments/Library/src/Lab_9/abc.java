
package Lab_9;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class abc {
	public static Map<Integer,Integer> getSquares(ArrayList<Integer>al){
		HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
		
		int i,j;
		i=j=0;
		
		Iterator<Integer> itr=al.iterator();
		while(itr.hasNext()){
			j++;
			i= itr.next();
			hm.put(j, i*i);
		}
		return hm;
	}
	
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		ArrayList<Integer> al=new ArrayList<Integer>();
		int n = sc.nextInt();
		//int[] arr = new int[n];
		for(int i=0 ; i<n ;i++){
			al.add(sc.nextInt());
		}
		System.out.println(getSquares(al));	
		sc.close();
	}
}

