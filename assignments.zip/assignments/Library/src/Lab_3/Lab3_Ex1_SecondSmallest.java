package Lab_3;

import java.util.Scanner;
public class Lab3_Ex1_SecondSmallest {
	public static int getSecondSmallest(int[] arr){
		
		int temp;
		for(int i=0; i<5 ; i++){
			for(int j=0 ; j<5-i-1 ; j++){
				if(arr[j] > arr[j+1]){
					temp     = arr[j];
					arr[j]   = arr[j+1];
					arr[j+1] = temp;
				}
			}
		}
		return arr[1];
	}
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		int[] arr = new int[5];
		for(int i=0 ; i<5 ; i++){
			arr[i]=sc.nextInt();
		}
		int a=getSecondSmallest(arr);
		System.out.println("Second smallest="+a);
		sc.close();
	}

}
