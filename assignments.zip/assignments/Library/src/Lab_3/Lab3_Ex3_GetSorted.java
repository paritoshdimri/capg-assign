package Lab_3;

import java.util.Scanner;

public class Lab3_Ex3_GetSorted {
	public static int[] getSorted(int[] arr) {
		int temp, s, tp;
		tp = temp = 0;
		for (int i = 0; i < 3; i++) {
			tp = arr[i];
			s = 0;
			while (tp > 0) {
				s = (s * 10) + (tp % 10);
				tp = tp / 10;
			}
			arr[i] = s;
		}
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3 - i - 1; j++) {
				if (arr[j] > arr[j + 1]) {
					temp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp;
				}
			}
		}
		return arr;
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int[] arr = new int[5];
		for (int i = 0; i < 3; i++) {
			arr[i] = sc.nextInt();
		}
		int[] a = getSorted(arr);
		
		for (int i = 0; i < 3; i++) {
			System.out.println(a[i]);
		}
		sc.close();
	}

}
