package Lab_3;

import java.util.Scanner;

public class Lab3_Ex4_Number_of_times {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		char ch[] = new char[5];
		for (int i = 0; i < 5; i++) {
			ch[i] = sc.next().charAt(0);
		}
		//counting characters in an character array
		for (char c = 'a'; c <= 'z'; c++) {
			int ctr = 0;
			for (char x : ch) {
				if (c == x) {
					ctr++;
				}
			}
			if (ctr != 0) {
				System.out.println("Character " + c + " is =" + ctr);
			}
		}
		sc.close();
	}

}
