package Lab_3;

import java.util.Scanner;

public class Lab3_Ex2_ChangeCase {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int n =sc.nextInt();
		String[] str = new String[n];
		for (int i = 0; i < n; i++) {
			str[i] = sc.next();
		}
		String temp;

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n - i - 1; j++) {
				if (str[j].compareTo(str[j + 1]) > 0) {
					temp = str[j + 1];
					str[j + 1] = str[j];
					str[j] = temp;
				}
			}
		}
		if(n % 2 != 0){
			for(int i=0 ; i<n/2+1 ; i++){
				str[i]=str[i].toUpperCase();
			}
			for(int i=n/2+2 ; i < n ; i++ ){
				str[i]=str[i].toLowerCase();
			}
		}
		else{
			for(int i=0 ; i<n/2 ; i++){
				str[i]=str[i].toUpperCase();
			}
			for(int i=n/2+2 ; i < n ; i++ ){
				str[i]=str[i].toLowerCase();
			}
		}
		System.out.println("Strings are =");
		for(int i = 0 ; i < n ; i++){
			System.out.println(str[i]);
		}
		sc.close();
	}
}
