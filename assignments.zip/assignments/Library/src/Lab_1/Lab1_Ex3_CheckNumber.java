package Lab_1;

import java.util.Scanner;

public class Lab1_Ex3_CheckNumber {

	public static boolean checkNumber(int n) {

		String str = Integer.toString(n);
		String[] d = str.split("");
		for (int i = 0; i < d.length - 1; i++) {

			if (Integer.parseInt(d[i]) > Integer.parseInt(d[i + 1])) {
				return false;
			}
		}
		return true;
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		boolean a = checkNumber(n);
		System.out.println(a);
		sc.close();
	}

}
