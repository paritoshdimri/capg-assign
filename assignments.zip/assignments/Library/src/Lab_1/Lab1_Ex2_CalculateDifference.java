package Lab_1;

import java.util.Scanner;
public class Lab1_Ex2_CalculateDifference {
	
	public static int calculateDifference(int n){
		
		int s1,s2,Sum;
		s1=s2=Sum=0;
		for(int i=1 ; i<n ; i++){
			s1+=i*i;
			s2+=i;
		}
		s2*=s2;
		Sum=s1-s2;
		return Sum;
	}
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		int n = sc.nextInt();
		int Sum = calculateDifference(n);
		System.out.println(Sum);
		sc.close();
	}

}
