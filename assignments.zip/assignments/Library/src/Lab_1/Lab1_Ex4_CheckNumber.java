package Lab_1;

import java.util.Scanner;
public class Lab1_Ex4_CheckNumber {
	
	public static boolean checkNumber(int n){
	          
	        while (n != 1) 
	        { 
	            if (n % 2 != 0) 
	                return false; 
	            n = n / 2; 
	        } 
	        return true; 
	}	
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		boolean a=checkNumber(n);
		System.out.println(a);
		sc.close();
	}

}
