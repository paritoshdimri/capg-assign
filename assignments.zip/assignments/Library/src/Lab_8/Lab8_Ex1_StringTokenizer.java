package Lab_8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Lab8_Ex1_StringTokenizer {
	
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter integers");
		String name = sc.nextLine();
		
		StringTokenizer st = new StringTokenizer(name);
		int n,sum =0;
		while(st.hasMoreTokens()){
			n=Integer.parseInt(st.nextToken());
			System.out.println(" "+n);
			sum+=n; 
		}
		System.out.println("Sum "+sum);
		
	}
}
