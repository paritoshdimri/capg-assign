package Lab_8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.Reader;

public class Lab8_Ex2_LineNumber {
	public static void main(String args[]) throws FileNotFoundException{
		
		File file = new File("C:\\Capgemini\\ReadMe.txt");
		FileReader fileInput = new FileReader(file);
		LineNumberReader lineNumberReader = new LineNumberReader(new FileReader(file));
		
		String line = null;
		try {			
			while((line =  lineNumberReader.readLine()) != null){
				System.out.print(lineNumberReader.getLineNumber() +" \t " +line+"\n");
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
