package Lab_8;

import java.util.Scanner;

public class Lab8_Ex7_Validity {
	public static boolean Validate(String str){
		int n = str.length();
		if(n >= 8){
			String str1 = str.substring(n-4, n);
			if(str1.equals("_job"))
				return true;
		}
		return false;
	}
	
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		boolean a= Validate(str);
		System.out.println(a);
		sc.close();
	}

}
