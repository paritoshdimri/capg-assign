package Lab_8;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import org.omg.CORBA.portable.Delegate;

public class Lab8_Ex6_CurrentDate {
	public static void Date(String str){
		DateTimeFormatter sdf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate date = LocalDate.now();
		String str1 = (date.format(sdf));
		
		
	}

	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		
		
	}

}
