package Lab_8;

import java.io.File;
import java.util.Scanner;

public class Lab8_Ex4_FileInfo {
	public static void main(String args[]){
		System.out.println("Enter file name");
		Scanner sc=new Scanner(System.in);
		String fi = sc.next();
		File file=new File(fi);
		
		System.out.println("File exists="+file.exists());
		System.out.println("file directory ="+file.isDirectory());
		System.out.println("File can read ="+file.canRead());
		System.out.println( "file can write = "+file.canWrite());
		System.out.println("Length ="+file.length());
		System.out.println("Can Execute"+file.canExecute());	
		
		sc.close();
	}
}
