package Lab_10;

import java.util.Scanner;

public class Lab_10_Ex_1_FileProgram {
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		String input=sc.next();
		String output=sc.next();
		
		Thread t=new Lab_10_Ex_1_CopyDataThread(input,output);
		t.start();
		sc.close();
	}

}
