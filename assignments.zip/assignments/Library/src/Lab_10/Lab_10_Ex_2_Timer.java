package Lab_10;

public class Lab_10_Ex_2_Timer implements Runnable {

	@Override
	public void run() {
		for (;;) {
			for (int i = 1; i <= 10; i++) {
				System.out.println(i);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println("Refreshed");
		}
	}

	public static void main(String args[]) {
		Thread rt = new Thread(new Lab_10_Ex_2_Timer());
		rt.start();
		System.out.println("Started");
	}

}
