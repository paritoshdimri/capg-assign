package Lab_4;

import java.util.Scanner;
public class Lab4_Ex1_cubes {
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int r,Sum;
		r=Sum=0;
		
		while(n >0){
			r=n%10;
			Sum+=r*r*r;
			n=n/10;
			
		}
		System.out.println("The sum is ="+Sum);
		sc.close();
	}
}
